package com.example.autoauction.admin.application;

import lombok.extern.slf4j.Slf4j;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.Map;
import java.util.Set;

@Slf4j
@Service
public class SystemSettingsService {

    public static final Set<String> ALLOWED_KEYS = Set.of(
            "deposit_percent",
            "platform_fee_percent",
            "commission_percent",
            "default_bid_step_percent",
            "diagnostic_deposit_amount",
            "auction_confirm_hours",
            "completed_auction_visibility_hours"
    );

    private final JdbcTemplate jdbc;

    public SystemSettingsService(JdbcTemplate jdbc) {
        this.jdbc = jdbc;
    }

    @Cacheable(value = "systemSettings", key = "#key")
    @Transactional(readOnly = true)
    public String get(String key) {
        try {
            return jdbc.queryForObject(
                    "SELECT setting_value FROM system_settings WHERE setting_key = ?",
                    String.class, key);
        } catch (Exception e) {
            log.warn("Setting '{}' not found, returning null", key);
            return null;
        }
    }

    @Cacheable(value = "systemSettings", key = "#key")
    @Transactional(readOnly = true)
    public int getInt(String key, int defaultValue) {
        String val = get(key);
        if (val == null) return defaultValue;
        try {
            return Integer.parseInt(val.trim());
        } catch (NumberFormatException e) {
            log.warn("Setting '{}' is not an integer: '{}', using default {}", key, val, defaultValue);
            return defaultValue;
        }
    }

    @CacheEvict(value = "systemSettings", key = "#key")
    @Transactional
    public void set(String key, String value) {
        if (!ALLOWED_KEYS.contains(key)) {
            throw new IllegalArgumentException("Недопустимый ключ настройки: '" + key +
                    "'. Разрешены: " + ALLOWED_KEYS);
        }
        int updated = jdbc.update(
                "UPDATE system_settings SET setting_value = ?, updated_at = NOW() WHERE setting_key = ?",
                value, key);
        if (updated == 0) {
            jdbc.update(
                    "INSERT INTO system_settings (setting_key, setting_value) VALUES (?, ?)",
                    key, value);
        }
        log.info("System setting '{}' updated to '{}'", key, value);
    }

    @CacheEvict(value = "systemSettings", allEntries = true)
    @Transactional
    public void setAll(Map<String, String> settings) {
        // Проверяем все ключи до записи — fail-fast
        settings.keySet().forEach(key -> {
            if (!ALLOWED_KEYS.contains(key)) {
                throw new IllegalArgumentException("Недопустимый ключ настройки: '" + key + "'");
            }
        });
        settings.forEach(this::set);
    }

    @Transactional(readOnly = true)
    public Map<String, String> getAll() {
        Map<String, String> result = new java.util.LinkedHashMap<>();
        jdbc.query("SELECT setting_key, setting_value FROM system_settings ORDER BY setting_key",
                rs -> {
                    result.put(rs.getString("setting_key"), rs.getString("setting_value"));
                });
        return result;
    }
}
